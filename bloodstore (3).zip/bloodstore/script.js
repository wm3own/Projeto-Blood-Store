
const titulosMenu = document.querySelectorAll('.container-titulos h2');
titulosMenu.forEach(titulo => {
  titulo.addEventListener('click', () => {
    const paginaDestino = titulo.getAttribute('data-link');
    if (paginaDestino) {
      window.location.href = paginaDestino;
    }
  });
});
