// =====================================
// HISTÓRICO DE COMPRAS
// =====================================

const compras = [

    {
        imagem: "imagens/shorts_jeans_personalizado.jpg",

        nome:
        "Shorts Jeans Personalizado",

        preco: "R$15,00",

        status: "pendente"
    },


    {
        imagem: "imagens/moletom_crucifixo.jpg",

        nome:  "Moletom com Crucifixo",

        preco: "R$20,00",

        status: "pendente"
    },


    {
        imagem: "imagens/toca_crucifixo.jpg",

        nome:
        "Toca com Crucifixo",

        preco: "R$12,90",

        status: "concluido"
    },


    {
        imagem: "imagens/regata_spike_gotico.jpg",

        nome:
        "CAMISETA PRETA ESTAMPA ESQUELETO",

        preco: "R$15,00",

        status: "concluido"
    },


    {
        imagem: "imagens/calca_baggy_jeans.jpg",

        nome:
        "Regata Spike Punk",

        preco: "R$20,00",

        status: "concluido"
    }
];


// =====================================
// LOCALIZAR LISTA DE COMPRAS
// =====================================

const listaCompras =
    document.getElementById("lista-compras");


// =====================================
// CRIAR COMPRAS
// =====================================

compras.forEach(function(compra) {


    const elemento =
        document.createElement("div");


    elemento.classList.add("compra");


    // =================================
    // STATUS
    // =================================

    let iconeStatus = "◉";

    let classeStatus = "";


    if (compra.status === "concluido") {

        iconeStatus = "✓";

        classeStatus = "concluido";

    }


    // =================================
    // HTML DA COMPRA
    // =================================

    elemento.innerHTML = `

        <div class="produto-imagem">

            <img
                src="${compra.imagem}"
                alt="${compra.nome}"
            >

        </div>


        <div class="produto-info">

            <h3>
                ${compra.nome}
            </h3>

            <p>
                ${compra.preco}
            </p>

        </div>


        <div class="status">

        <button
            class="acompanhar botao-acompanhar"
            data-produto="${compra.nome}"
        >
            ACOMPANHE<br>
            SEU PEDIDO
        </button>


            <span
                class="status-icon ${classeStatus}"
            >

                ${iconeStatus}

            </span>

        </div>

    `;


    listaCompras.appendChild(elemento);

});


// =====================================
// SCROLL DO HISTÓRICO
// =====================================

const lista =
    document.getElementById("lista-compras");

const barra =
    document.querySelector(".barra-scroll");

const trilho =
    document.querySelector(".divisoria");


// =====================================
// VARIÁVEIS DO SCROLL
// =====================================

let arrastando = false;

let inicioMouse = 0;

let inicioBarra = 0;


// =====================================
// CLICAR NA BARRA
// =====================================

barra.addEventListener("mousedown", function(event) {

    arrastando = true;

    inicioMouse = event.clientY;

    inicioBarra = barra.offsetTop;

    event.preventDefault();

});


// =====================================
// MOVIMENTO DO MOUSE
// =====================================

document.addEventListener("mousemove", function(event) {

    if (!arrastando) return;


    let movimento =
        event.clientY - inicioMouse;


    let novaPosicao =
        inicioBarra + movimento;


    const limite =
        trilho.clientHeight -
        barra.offsetHeight;


    if (novaPosicao < 0) {

        novaPosicao = 0;

    }


    if (novaPosicao > limite) {

        novaPosicao = limite;

    }


    barra.style.top =
        novaPosicao + "px";


    // =================================
    // CONVERTER PARA SCROLL
    // =================================

    const porcentagem =
        novaPosicao / limite;


    const scrollMaximo =
        lista.scrollHeight -
        lista.clientHeight;


    lista.scrollTop =
        porcentagem * scrollMaximo;

});


// =====================================
// SOLTAR O MOUSE
// =====================================

document.addEventListener("mouseup", function() {

    arrastando = false;

});


// =====================================
// RODINHA DO MOUSE
// =====================================

lista.addEventListener(
    "wheel",
    function(event) {

        event.preventDefault();

        lista.scrollTop += event.deltaY;

        atualizarBarra();

    },
    {
        passive: false
    }
);


// =====================================
// ATUALIZAR BARRA
// =====================================

function atualizarBarra() {

    const scrollMaximo =
        lista.scrollHeight -
        lista.clientHeight;


    if (scrollMaximo <= 0) {

        barra.style.top = "0px";

        return;

    }


    const limite =
        trilho.clientHeight -
        barra.offsetHeight;


    const porcentagem =
        lista.scrollTop /
        scrollMaximo;


    barra.style.top =
        (porcentagem * limite) + "px";

}


// =====================================
// MODAL DE DOAÇÕES
// =====================================

const btnDoacoes =
    document.getElementById("btnDoacoes");

const modalDoacoes =
    document.getElementById("modalDoacoes");

const fecharDoacoes =
    document.getElementById("fecharDoacoes");

// =====================================
// SCROLL DAS DOAÇÕES
// =====================================

const listaDoacoes =
    document.getElementById("lista-doacoes");

const barraDoacoes =
    document.getElementById("barraDoacoes");

const trilhoDoacoes =
    document.getElementById("trilhoDoacoes");


// =====================================
// VARIÁVEIS
// =====================================

let arrastandoDoacoes = false;

let inicioMouseDoacoes = 0;

let inicioBarraDoacoes = 0;


// =====================================
// CLICAR NA BARRA
// =====================================

barraDoacoes.addEventListener(
    "mousedown",
    function(event) {

        arrastandoDoacoes = true;

        inicioMouseDoacoes = event.clientY;

        inicioBarraDoacoes =
            barraDoacoes.offsetTop;

        event.preventDefault();

    }
);


// =====================================
// MOVER A BARRA
// =====================================

document.addEventListener(
    "mousemove",
    function(event) {

        if (!arrastandoDoacoes) return;


        let movimento =
            event.clientY - inicioMouseDoacoes;


        let novaPosicao =
            inicioBarraDoacoes + movimento;


        const limite =
            trilhoDoacoes.clientHeight -
            barraDoacoes.offsetHeight;


        // Impede sair do trilho

        if (novaPosicao < 0) {

            novaPosicao = 0;

        }


        if (novaPosicao > limite) {

            novaPosicao = limite;

        }


        // Move a barra

        barraDoacoes.style.top =
            novaPosicao + "px";


        // =================================
        // CONVERTER PARA SCROLL
        // =================================

        if (limite > 0) {

            const porcentagem =
                novaPosicao / limite;


            const scrollMaximo =
                listaDoacoes.scrollHeight -
                listaDoacoes.clientHeight;


            listaDoacoes.scrollTop =
                porcentagem * scrollMaximo;

        }

    }
);


// =====================================
// SOLTAR A BARRA
// =====================================

document.addEventListener(
    "mouseup",
    function() {

        arrastandoDoacoes = false;

    }
);


// =====================================
// RODINHA DO MOUSE
// =====================================

listaDoacoes.addEventListener(
    "wheel",
    function(event) {

        event.preventDefault();


        listaDoacoes.scrollTop +=
            event.deltaY;


        atualizarBarraDoacoes();

    },
    {
        passive: false
    }
);


// =====================================
// ATUALIZAR BARRA
// =====================================

function atualizarBarraDoacoes() {

    const scrollMaximo =
        listaDoacoes.scrollHeight -
        listaDoacoes.clientHeight;


    // Se não existe conteúdo suficiente
    // para rolar

    if (scrollMaximo <= 0) {

        barraDoacoes.style.top = "0px";

        return;

    }


    const limite =
        trilhoDoacoes.clientHeight -
        barraDoacoes.offsetHeight;


    const porcentagem =
        listaDoacoes.scrollTop /
        scrollMaximo;


    barraDoacoes.style.top =
        (porcentagem * limite) + "px";

}


// =====================================
// ATUALIZAR QUANDO O MODAL ABRIR
// =====================================

btnDoacoes.addEventListener(
    "click",
    function() {

        // Espera o navegador renderizar
        // o modal antes de calcular

        setTimeout(
            function() {

                atualizarBarraDoacoes();

            },
            50
        );

    }
);
// =====================================
// ABRIR MODAL
// =====================================

btnDoacoes.addEventListener(
    "click",
    function() {

        modalDoacoes.style.display = "flex";

        document.body.style.overflow = "hidden";

    }
);


// =====================================
// FECHAR PELO X
// =====================================

fecharDoacoes.addEventListener(
    "click",
    function() {

        modalDoacoes.style.display = "none";

        document.body.style.overflow = "";

    }
);


// =====================================
// FECHAR CLICANDO FORA
// =====================================

modalDoacoes.addEventListener(
    "click",
    function(event) {

        if (event.target === modalDoacoes) {

            modalDoacoes.style.display = "none";

            document.body.style.overflow = "";

        }

    }
);


// =====================================
// FECHAR COM ESC
// =====================================

document.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Escape") {

            modalDoacoes.style.display = "none";

            document.body.style.overflow = "";

        }

    }
);

// =====================================
// MODAL ACOMPANHAR PEDIDO
// =====================================

const modalAcompanhar =
    document.getElementById("modalAcompanhar");

const fecharAcompanhar =
    document.getElementById("fecharAcompanhar");

const imagemPedido =
    document.getElementById("imagemPedido");

const nomePedido =
    document.getElementById("nomePedido");


// =====================================
// BOTÕES ACOMPANHAR
// =====================================

document.addEventListener(
    "click",
    function(event) {

        const botao =
            event.target.closest(".botao-acompanhar");


        if (!botao) return;


        // Procura a compra correspondente

        const compra =
            botao.closest(".compra");


        const imagem =
            compra.querySelector(
                ".produto-imagem img"
            );


        const nome =
            compra.querySelector(
                ".produto-info h3"
            );


        // Coloca os dados no modal

        imagemPedido.src =
            imagem.src;

        imagemPedido.alt =
            nome.textContent.trim();

        nomePedido.textContent =
            nome.textContent.trim();


        // Abre o modal

        modalAcompanhar.style.display =
            "flex";

        document.body.style.overflow =
            "hidden";

    }
);


// =====================================
// FECHAR
// =====================================

fecharAcompanhar.addEventListener(
    "click",
    function() {

        modalAcompanhar.style.display =
            "none";

        document.body.style.overflow =
            "";

    }
);


// =====================================
// FECHAR CLICANDO FORA
// =====================================

modalAcompanhar.addEventListener(
    "click",
    function(event) {

        if (
            event.target ===
            modalAcompanhar
        ) {

            modalAcompanhar.style.display =
                "none";

            document.body.style.overflow =
                "";

        }

    }
);


// =====================================
// FECHAR COM ESC
// =====================================

document.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Escape" &&
            modalAcompanhar.style.display === "flex"
        ) {

            modalAcompanhar.style.display =
                "none";

            document.body.style.overflow =
                "";

        }

    }
);