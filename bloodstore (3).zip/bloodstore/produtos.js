let carrinho = [];

const btnAbrirCarrinho = document.getElementById('abrir-carrinho');
const btnFecharCarrinho = document.getElementById('fechar-carrinho');
const drawerCarrinho = document.getElementById('carrinho-drawer');
const overlayCarrinho = document.getElementById('carrinho-overlay');
const containerItens = document.getElementById('carrinho-itens');
const totalEl = document.getElementById('carrinho-total-valor');
const qtdEl = document.getElementById('carrinho-qtd');

function toggleCarrinho() {
    drawerCarrinho.classList.toggle('ativo');
    overlayCarrinho.classList.toggle('ativo');
}

btnAbrirCarrinho.addEventListener('click', toggleCarrinho);
btnFecharCarrinho.addEventListener('click', toggleCarrinho);
overlayCarrinho.addEventListener('click', toggleCarrinho);

document.querySelectorAll('.btn-carrinho').forEach(button => {
    button.addEventListener('click', (e) => {
        const card = e.target.closest('.produto-card');
        const titulo = card.querySelector('.produto-titulo').textContent.trim();
        const precoTexto = card.querySelector('.preco-atual').textContent.trim();
        const imagemSrc = card.querySelector('.produto-media img').src;
        
        const preco = parseFloat(precoTexto.replace('R$', '').replace(',', '.').trim());

        const jaExiste = carrinho.find(item => item.titulo === titulo);
        if (jaExiste) {
            alert('Esta peça única já está no seu carrinho!');
            toggleCarrinho();
            return;
        }

        carrinho.push({ titulo, preco, imagemSrc });
        atualizarCarrinho();
        toggleCarrinho();
    });
});

function atualizarCarrinho() {
    containerItens.innerHTML = '';
    let total = 0;

    carrinho.forEach((item, index) => {
        total += item.preco;

        const itemDiv = document.createElement('div');
        itemDiv.classList.add('item-carrinho');
        itemDiv.innerHTML = `
            <img src="${item.imagemSrc}" alt="${item.titulo}">
            <div class="item-detalhes">
                <h4>${item.titulo}</h4>
                <span>R$ ${item.preco.toFixed(2).replace('.', ',')}</span>
            </div>
            <button class="btn-remover" onclick="removerDoCarrinho(${index})">&times;</button>
        `;
        containerItens.appendChild(itemDiv);
    });

    totalEl.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
    qtdEl.textContent = carrinho.length;
}

window.removerDoCarrinho = function(index) {
    carrinho.splice(index, 1);
    atualizarCarrinho();
};